# Basic Network Sniffer

## Description
This project is a basic network sniffer developed using Python and the Scapy library. It captures live network packets and displays useful information such as:

- Source IP Address
- Destination IP Address
- Protocol (TCP, UDP, ICMP, Other)
- Packet Length
- Payload (if available)

## Requirements

- Python 3.x
- Scapy
- Npcap (Windows only)

## Installation

Install Scapy:

```bash
pip install scapy
```

## Run the Project

```bash
python sniffer.py
```

## Features

- Captures live network traffic
- Displays packet details
- Identifies network protocols
- Shows packet payload

## Author

Your Name