from scapy.all import sniff, IP, TCP, UDP, ICMP, Raw

# Function to process each captured packet
def packet_callback(packet):

    # Check if the packet has an IP layer
    if packet.haslayer(IP):

        print("=" * 60)

        # Display source and destination IP addresses
        print("Source IP      :", packet[IP].src)
        print("Destination IP :", packet[IP].dst)

        # Identify the protocol
        if packet.haslayer(TCP):
            print("Protocol       : TCP")

        elif packet.haslayer(UDP):
            print("Protocol       : UDP")

        elif packet.haslayer(ICMP):
            print("Protocol       : ICMP")

        else:
            print("Protocol       : Other")

        # Display packet length
        print("Packet Length  :", len(packet), "bytes")

        # Display payload if available
        if packet.haslayer(Raw):
            try:
                payload = packet[Raw].load.decode(errors="ignore")
                print("Payload:")
                print(payload)
            except:
                print("Payload:")
                print(packet[Raw].load)

# Start packet capture
print("Starting Network Sniffer...")
print("Press Ctrl + C to stop.\n")

sniff(prn=packet_callback, store=False)